//
//  ViewController.swift
//  plistandnsuserdefaul
//
//  Created by MACOS on 11/24/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func createplistdata(_ sender: AnyObject) {
        
        let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
        let path = documentDirectory.appending("/profile.plist")
        
        if(!FileManager().fileExists(atPath: path)){
            print(path)
            
            let data : [String: String] = [
                "Company": "My Company",
                "FullName": "My Full Name",
                "FirstName": "My First Name",
                "LastName": "My Last Name",
                // any other key values
            ]
            
            let someData = NSDictionary(dictionary: data)
            let isWritten = someData.write(toFile: path, atomically: true)
            print("is the file created: \(isWritten)")
            
            
            
        }else{
            print("file exists")
        }
        
        
    }
    
    @IBAction func displayplistdata(_ sender: AnyObject) {
        
        
        let document = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
        var  path = document.appending("/profile.plist")
        
        let somedata = NSDictionary(contentsOfFile: path);
        
        
        print(somedata);
        
        
        
        
        
        
        
    }
    
}

